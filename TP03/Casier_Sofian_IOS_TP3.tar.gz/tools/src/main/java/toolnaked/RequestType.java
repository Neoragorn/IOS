package toolnaked;

public enum RequestType {
	GET, POST;
}
