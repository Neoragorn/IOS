package toolnaked;

import java.io.IOException;



public interface ServletFileI {

 public void handleRequest(Request r) throws IOException;
}
