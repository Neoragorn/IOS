package toolnaked;

/** Logs to System.err */
public class BasicLogger {
  public void log (String msg) { System.err.println(msg); }
}
