package Exception;

public class AccountDoNoExistException extends Exception {


	public AccountDoNoExistException(String msg) {
		super(msg);		
	}

}
