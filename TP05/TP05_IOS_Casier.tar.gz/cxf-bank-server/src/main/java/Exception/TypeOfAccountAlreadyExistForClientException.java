package Exception;

public class TypeOfAccountAlreadyExistForClientException extends Exception{
	public TypeOfAccountAlreadyExistForClientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
