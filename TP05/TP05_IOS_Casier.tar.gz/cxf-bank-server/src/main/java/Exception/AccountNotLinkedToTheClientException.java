package Exception;

public class AccountNotLinkedToTheClientException extends Exception {
	public AccountNotLinkedToTheClientException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
