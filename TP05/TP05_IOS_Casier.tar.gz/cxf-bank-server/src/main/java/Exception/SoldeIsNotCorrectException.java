package Exception;

public class SoldeIsNotCorrectException extends Exception {
	public SoldeIsNotCorrectException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
