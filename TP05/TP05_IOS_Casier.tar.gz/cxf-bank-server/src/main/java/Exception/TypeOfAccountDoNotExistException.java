package Exception;

public class TypeOfAccountDoNotExistException extends Exception{
	public TypeOfAccountDoNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
