package Exception;

public class ClientStillHasAnAccountException extends Exception{
	public ClientStillHasAnAccountException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
