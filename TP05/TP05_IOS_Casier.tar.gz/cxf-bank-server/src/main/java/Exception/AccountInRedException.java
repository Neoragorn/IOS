package Exception;

public class AccountInRedException extends Exception{

	public AccountInRedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
