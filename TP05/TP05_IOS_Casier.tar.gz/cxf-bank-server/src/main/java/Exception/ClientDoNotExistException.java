package Exception;

public class ClientDoNotExistException extends Exception{
	public ClientDoNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
