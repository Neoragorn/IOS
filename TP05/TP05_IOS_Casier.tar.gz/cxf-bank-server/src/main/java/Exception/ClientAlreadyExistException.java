package Exception;

public class ClientAlreadyExistException extends Exception{
	public ClientAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
