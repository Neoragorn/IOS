@javax.xml.bind.annotation.XmlSchema(namespace = "http://bankInterface/")
package ios.client;
